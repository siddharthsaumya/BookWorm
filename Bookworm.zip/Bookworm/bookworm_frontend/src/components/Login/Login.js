import './Login.css';
import React, { useState } from 'react';
import {baseUrl} from '../../Server';
import axios from 'axios';
import CookiesService from '../../services/CookiesService';

function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e) => {
    e.preventDefault();
    const userData = {
      username: username,
      password: password
    };

    axios.post(baseUrl+'Auth/Login', userData)
      .then(response => {
        console.log('Login successful:', response.data);
        CookiesService.setToken(response.data);
        alert("Login successful");
        window.location.href = "/";
      })
      .catch(e => {
        setError("Invalid Credentials");
        alert(error);
        console.error("Error while login:",e.response.data)
      });
  };

    return (
      <div>
      <h2>Login</h2>
      <form>
        <div>
          <input
            type="text"
            placeholder='Username'
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
        </div>
        <div>
          <input
            type="password"
            placeholder='Password'
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <button type="button" onClick={handleLogin}>Login</button>
      </form>
    </div>
    );
  }
  
  export default Login;
  