import './Register.css';
import React, { useState } from 'react';
import axios from 'axios';
import { baseUrl } from '../../Server';
import CookiesService from '../../services/CookiesService';

function Register() {
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [email, setEmail] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [passwordValidation, setPasswordValidation] = useState({
    hasNumber: false, hasSpecialChar: false, isLengthValid: false
  });
  const [dataValidation, setDataValidation] = useState({
    nameValid: true, usernameValid: true, emailValid: true
  });

  const validate = () => {
    if (name.length > 0 && username.length > 0 && email.length > 0) {
      const emailRegex = /^[\w-]+(\.[\w-]+)*@[a-zA-Z0-9]+(\.[a-zA-Z0-9]+)*(\.[a-zA-Z]{2,})$/;

      setDataValidation({
        emailValid: emailRegex.test(email),
        usernameValid: true,
        nameValid: true
      });
    }
  }

  const validatePassword = (value) => {
    if (value.length === 0) {
      setPasswordValidation({
        hasNumber: false,
        hasSpecialChar: false,
        isLengthValid: false
      });
    } else {
      const numberRegex = /[0-9]/;
      const specialCharRegex = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/;
      setPasswordValidation({
        hasNumber: numberRegex.test(value),
        hasSpecialChar: specialCharRegex.test(value),
        isLengthValid: value.length >= 8
      });
    }
  };


  const handleRegister = () => {
    validate();
    if(dataValidation.nameValid && dataValidation.usernameValid && dataValidation.emailValid && passwordValidation.isLengthValid && passwordValidation.hasNumber && passwordValidation.hasSpecialChar){
      const userData = {
        name: name,
        username: username,
        password: password,
        email: email
      };
  
      axios.post(baseUrl + 'Auth/Register', userData)
        .then(response => {
          console.log('Registration successful:', response.data);
          CookiesService.setToken(response.data);
          alert("Registration successful");
          window.location.href = "/";
        })
        .catch(error => {
          setErrorMessage(error.response.data);
          alert("Username/Email already exists");
          console.error('Error:', error.response.data);
        });
    }else{
      alert("Invalid input. User not registered.");
    }
  };

  return (
    <div>
      <h2>Register</h2>
      <form>
        <div>
          <label>Name:</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            style={{
              borderColor: !dataValidation.nameValid ? 'red' : ''
            }}
          />
        </div>
        <div>
          <label>Username:</label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            style={{ borderColor: errorMessage === 'Username is already taken' && !dataValidation.usernameValid  ? 'red' : '' }}
          />
        </div>
        <div>
          <label>Password:</label>
          <input
            type="password"
            value={password}
            onChange={(e) => {
              setPassword(e.target.value);
              validatePassword(e.target.value);
            }}
            style={{
              borderColor: (password.length > 0 && (!passwordValidation.isLengthValid || !passwordValidation.hasNumber || !passwordValidation.hasSpecialChar)) ? 'red' : ''
            }}
          />
          <div style={{ marginTop: '0.5rem', fontSize: '0.8rem' }}>
            {passwordValidation.isLengthValid ? '✓ Minimum 8 characters' : '✗ Minimum 8 characters'}
            <br />
            {passwordValidation.hasNumber ? '✓ Contains number' : '✗ Contains number'}
            <br />
            {passwordValidation.hasSpecialChar ? '✓ Contains special character' : '✗ Contains special character'}
          </div>
        </div>
        <div>
          <label>Email:</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            style={{ borderColor: errorMessage === 'Email already exist' || !dataValidation.emailValid ? 'red' : '' }}
          />
        </div>
        <button type="button" onClick={handleRegister}>Register</button>
      </form>
    </div>
  );
}

export default Register;
