import React from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import AuthPage from './pages/AuthPage';
import LandingPage from './pages/LandingPage';
import CookiesService from './services/CookiesService';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={CookiesService.isAuthenticated() ? <LandingPage /> : <AuthPage />}/>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
