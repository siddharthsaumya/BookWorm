import Cookies from 'js-cookie';

const TOKEN_KEY = 'user_token';

const CookiesService = {

  setToken(token) {
    Cookies.set(TOKEN_KEY, token);
    console.log("Cookie Stored");
  },


  getToken() {
    const gotCookie = Cookies.get(TOKEN_KEY);
    console.log("Got cookie: ",gotCookie);
    return gotCookie;
  },


  removeToken() {
    Cookies.remove(TOKEN_KEY);
    console.log("Cookie removed");
  },

  isAuthenticated() {
    var checkauth = !!this.getToken();
    console.log("Auth status: ",checkauth);
    return checkauth;
  }
};

export default CookiesService;