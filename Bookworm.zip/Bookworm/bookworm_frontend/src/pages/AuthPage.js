import React, { useState } from 'react';

import LoginComponent from '../components/Login/Login';
import RegisterComponent from '../components/Register/Register';

function AuthPage() {
    const [showLogin, setShowLogin] = useState(true);
    const [showRegister, setShowRegister] = useState(false);

    const renderLoginLink = () => {
        setShowLogin(true);
        setShowRegister(false);
      };
    
      const renderRegisterLink = () => {
        setShowLogin(false);
        setShowRegister(true);
      };

  return (
    <>
    <button onClick={renderLoginLink}>Login</button>
    <button onClick={renderRegisterLink}>Register</button><br/>

    {showLogin && <LoginComponent/>}
    {showRegister && <RegisterComponent />}
  </>
  );
}

export default AuthPage;
