import React, {useEffect, useState} from 'react';
import CookiesService from '../services/CookiesService';
import JWTDecoder from '../utils/JwtDecoder';

function LandingPage() {
  const [decodedToken, setDecodedToken] = useState({nameid:0,role:0});
  useEffect(() => {
    const DToken = JWTDecoder(CookiesService.getToken());
    setDecodedToken({nameid:DToken.nameid,role:DToken.role})
  }, []);
 
  const handleLogout = () => {
    CookiesService.removeToken();
    window.location.href = "/";
  };
  return (
    <>
    <h4>LandingPage</h4>
      <button onClick={handleLogout}>Logout</button>
          {decodedToken.role == 1 ? (
            <div>
              <p>ADMIN</p>
            </div>
          ):(
            <div>
              <p>BUYER/SELLER</p>
            </div>
          )}
        
    </>
  );
}

export default LandingPage;
