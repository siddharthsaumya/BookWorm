import React, {useEffect} from 'react';
import CookiesService from '../services/CookiesService';

function LandingPage() {
  const handleLogout = () => {
    CookiesService.removeToken();
    window.location.href = "/";
  };

  return (
    <>
    <h4>LandingPage</h4>
      <button onClick={handleLogout}>Logout</button>
    </>
  );
}

export default LandingPage;
