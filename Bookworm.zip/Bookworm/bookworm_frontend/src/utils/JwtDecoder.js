import React from 'react';
import {jwtDecode} from 'jwt-decode';

function JWTDecoder(token) {
    const decodedToken = jwtDecode(token);
    console.log('Decoded Token:', decodedToken);
    return decodedToken; 
}

export default JWTDecoder;
