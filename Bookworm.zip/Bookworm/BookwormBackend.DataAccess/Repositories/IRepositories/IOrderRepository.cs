﻿using BookwormBackend.DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookwormBackend.DataAccess.Repositories.IRepositories
{
    public interface IOrderRepository
    {
        public Task<IEnumerable<Order>> GetAllOrders();
        Task<IEnumerable<Order>> GetOrdersByBuyerId(int buyerId);

        Task<int> AddOrderAsync(Order order);
        Task<bool> UpdateOrderStatusAsync(int orderId, int status);


    }
}
