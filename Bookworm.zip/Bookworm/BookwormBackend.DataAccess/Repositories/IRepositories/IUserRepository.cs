﻿using BookwormBackend.DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookwormBackend.DataAccess.Repositories.IRepositories
{
    public interface IUserRepository
    {
        User GetById(int userId);

        void Add(User user);
        void Update(User user);
        Address GetAddressByUserId(int userId);
    }
}
