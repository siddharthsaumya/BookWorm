﻿using BookwormBackend.DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookwormBackend.DataAccess.Repositories.IRepositories
{
    public interface ICartRepository
    {
        Task<IEnumerable<CartItem>> GetCartItemsByUserId(int userId);

        Task<CartItem> AddToCart(CartItem cartItem);

        Task UpdateCartItemAsync(CartItem cartItem);

        Task<CartItem> GetCartItemByIdAsync(int id);

        Task DeleteCartItemAsync(int id);

    }
}
