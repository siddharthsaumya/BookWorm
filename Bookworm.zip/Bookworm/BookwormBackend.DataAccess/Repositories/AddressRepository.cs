﻿using BookwormBackend.DataAccess.Models;
using BookwormBackend.DataAccess.Repositories.IRepositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookwormBackend.DataAccess.Repositories
{
    public class AddressRepository : IAddressRepository
    {
        private readonly BookwormDBContext _context;

        public AddressRepository(BookwormDBContext context)
        {
            _context = context;
        }

        public void AddAddress(Address address)
        {
            _context.Addresses.Add(address);
            _context.SaveChanges();
        }

        public void UpdateAddress(Address address)
        {
            _context.Addresses.Update(address);
            _context.SaveChanges();
        }

        public Address GetAddressByUserId(int userId)
        {
            return _context.Addresses.FirstOrDefault(a => a.UserId == userId);
        }
    }
}
