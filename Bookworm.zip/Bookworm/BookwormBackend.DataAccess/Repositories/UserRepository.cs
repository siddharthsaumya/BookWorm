﻿using BookwormBackend.DataAccess.Models;
using BookwormBackend.DataAccess.Repositories.IRepositories;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookwormBackend.DataAccess.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly BookwormDBContext _context;

        public UserRepository(BookwormDBContext context)
        {
            _context = context;
        }

        public User GetById(int userId)
        {
            return _context.Users.Find(userId);
        }

        public Address GetAddressByUserId(int userId)
        {
            return _context.Addresses.FirstOrDefault(a => a.UserId == userId);
        }

        public void Add(User user)
        {
            if (_context.Users.Any(u => u.Email == user.Email || u.Username == user.Username))
            {
                throw new Exception("User with the same email or username already exists.");
            }

            _context.Users.Add(user);
            _context.SaveChanges();
        }

        public async Task<User> AddUser(User user)
        {
            if (await _context.Users.AnyAsync(u => u.Email == user.Email || u.Username == user.Username))
            {
                throw new Exception("User with the same email or username already exists.");
            }

            _context.Users.Add(user);
            await _context.SaveChangesAsync();
            return user;
        }

        public void Update(User user)
        {
            _context.Users.Update(user);
            _context.SaveChanges();
        }

        public async Task<User> GetUserByUsername(string username)
        {
            return await _context.Users.FirstOrDefaultAsync(u => u.Username == username);
        }

        public async Task<User> GetUserByEmail(string email)
        {
            return await _context.Users.FirstOrDefaultAsync(u => u.Email == email);
        }

    }
}
