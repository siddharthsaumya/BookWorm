﻿using BookwormBackend.DataAccess.Models;
using BookwormBackend.DataAccess.Repositories.IRepositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookwormBackend.DataAccess.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly BookwormDBContext _context;

        public UserRepository(BookwormDBContext context)
        {
            _context = context;
        }

        public User GetById(int userId)
        {
            return _context.Users.Find(userId);
        }

        public Address GetAddressByUserId(int userId)
        {
            return _context.Addresses.FirstOrDefault(a => a.UserId == userId);
        }

        public void Add(User user)
        {
            _context.Users.Add(user);
            _context.SaveChanges();
        }

        public void Update(User user)
        {
            _context.Users.Update(user);
            _context.SaveChanges();
        }

    }
}
