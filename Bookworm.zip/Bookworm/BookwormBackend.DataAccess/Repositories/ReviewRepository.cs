﻿using BookwormBackend.DataAccess.Models;
using BookwormBackend.DataAccess.Repositories.IRepositories;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookwormBackend.DataAccess.Repositories
{
    public class ReviewRepository : IReviewRepository
    {
        private readonly BookwormDBContext _context;

        public ReviewRepository(BookwormDBContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        public IEnumerable<Review> GetAll()
        {
            return _context.Reviews.ToList();
        }

        public void Add(Review review)
        {
            if (review == null)
            {
                throw new ArgumentNullException(nameof(review));
            }

            _context.Reviews.Add(review);
            _context.SaveChanges();
        }

        public IEnumerable<Review> GetReviewsByBookId(int bookId)
        {
            return _context.Reviews.Where(review => review.BookId == bookId).ToList();
        }
    }
}
