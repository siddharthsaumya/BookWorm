﻿using BookwormBackend.DataAccess.Models;
using BookwormBackend.DataAccess.Repositories.IRepositories;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookwormBackend.DataAccess.Repositories
{
    public class OrderRepository : IOrderRepository
    {
        private readonly BookwormDBContext _context;

        public OrderRepository(BookwormDBContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Order>> GetAllOrders()
        {
            return await _context.Orders
                .Include(o => o.Book)
                    .ThenInclude(b => b.Genre)
                .Include(o => o.Book)
                    .ThenInclude(g => g.Seller)
                .ToListAsync();
        }

        public async Task<IEnumerable<Order>> GetOrdersByBuyerId(int buyerId)
        {
            return await _context.Orders
                .Include(o => o.Book)
                    .ThenInclude(b => b.Genre)
                .Include(o => o.Book)
                    .ThenInclude(g => g.Seller)
                .Where(o => o.BuyerId == buyerId)
                .ToListAsync();
        }

        public async Task<int> AddOrderAsync(Order order)
        {
            _context.Orders.Add(order);
            await _context.SaveChangesAsync();
            return order.Id; // Return the Id of the created order
        }

        public async Task<bool> UpdateOrderStatusAsync(int orderId, int status)
        {
            var order = await _context.Orders.FindAsync(orderId);
            if (order == null)
                return false; // Order not found

            order.Status = status;
            await _context.SaveChangesAsync();
            return true; // Order status updated successfully
        }


    }
}
