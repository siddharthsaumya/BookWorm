﻿using BookwormBackend.DataAccess.Models;
using BookwormBackend.DataAccess.Repositories.IRepositories;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookwormBackend.DataAccess.Repositories
{
    public class OrderRepository: IOrderRepository
    {
        private readonly BookwormDBContext _context;

        public OrderRepository(BookwormDBContext context)
        {
            _context = context;
        }

        public IEnumerable<Order> GetAllOrders()
        {
            return _context.Orders
                .Include(o => o.OrderItems)
                .ThenInclude(b => b.Book)
                .ToList();
        }

        public async Task<IEnumerable<Order>> GetOrdersByBuyerIdAsync(int buyerId)
        {
            return await _context.Orders
                .Where(o => o.BuyerId == buyerId)
                .Include(o => o.OrderItems)
                .ThenInclude(b => b.Book)
                .ToListAsync();
        }

    }
}
