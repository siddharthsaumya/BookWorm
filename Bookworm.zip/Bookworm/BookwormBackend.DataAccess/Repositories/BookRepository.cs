﻿using BookwormBackend.DataAccess.Models;
using BookwormBackend.DataAccess.Repositories.IRepositories;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookwormBackend.DataAccess.Repositories
{
    public class BookRepository : IBookRepository
    {

            private readonly BookwormDBContext _context;

            public BookRepository(BookwormDBContext context)
            {
                _context = context ?? throw new ArgumentNullException(nameof(context));
            }

            public IEnumerable<Book> GetAll()
            {
                return _context.Books
                    .Include(g => g.Genre)
                    .ToList();
            }

            public Book GetById(int id)
            {
                return _context.Books.Include(book => book.Genre).FirstOrDefault(book => book.Id == id);
            }

        public void Add(Book book)
            {
                if (book == null)
                {
                    throw new ArgumentNullException(nameof(book));
                }

                _context.Books.Add(book);
                _context.SaveChanges();
            }

            public void Update(Book book)
            {
                if (book == null)
                {
                    throw new ArgumentNullException(nameof(book));
                }

                _context.Entry(book).State = EntityState.Modified;
                _context.SaveChanges();
            }

            public void Delete(Book book)
            {
                if (book == null)
                {
                    throw new ArgumentNullException(nameof(book));
                }

                _context.Books.Remove(book);
                _context.SaveChanges();
            }
        }
    }
