﻿using BookwormBackend.DataAccess.Models;
using BookwormBackend.DataAccess.Repositories.IRepositories;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookwormBackend.DataAccess.Repositories
{
    public class CartRepository : ICartRepository
    {
        private readonly BookwormDBContext _context;

        public CartRepository(BookwormDBContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<CartItem>> GetCartItemsByUserId(int userId)
        {
            return await _context.CartItems
                .Include(o => o.Book)
                    .ThenInclude(b => b.Genre)
                .Include(o => o.Book)
                    .ThenInclude(g => g.Seller)
                .Where(c => c.UserId == userId)
                .ToListAsync();
        }

        public async Task<CartItem> AddToCart(CartItem cartItem)
        {
            // Check if a cart item with the same BookId already exists for the same UserId
            if (await _context.CartItems.AnyAsync(ci => ci.UserId == cartItem.UserId && ci.BookId == cartItem.BookId))
            {
                throw new Exception("A cart item with the same BookId already exists for this User.");
            }

            _context.CartItems.Add(cartItem);
            await _context.SaveChangesAsync();
            return cartItem;
        }

        public async Task UpdateCartItemAsync(CartItem cartItem)
        {
            _context.Entry(cartItem).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }

        public async Task<CartItem> GetCartItemByIdAsync(int id)
        {
            return await _context.CartItems.FindAsync(id);
        }

        public async Task DeleteCartItemAsync(int id)
        {
            var cartItem = await _context.CartItems.FindAsync(id);
            if (cartItem != null)
            {
                _context.CartItems.Remove(cartItem);
                await _context.SaveChangesAsync();
            }
        }


    }
}
