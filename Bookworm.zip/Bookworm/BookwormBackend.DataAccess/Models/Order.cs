﻿using System;
using System.Collections.Generic;

namespace BookwormBackend.DataAccess.Models
{
    public partial class Order
    {
        public int Id { get; set; }
        public int? BuyerId { get; set; }
        public DateTime? OrderDate { get; set; }
        public int? BookId { get; set; }
        public int? Quantity { get; set; }
        public int? Amount { get; set; }
        public int? Status { get; set; }

        public virtual Book? Book { get; set; }
        public virtual User? Buyer { get; set; }
    }
}
