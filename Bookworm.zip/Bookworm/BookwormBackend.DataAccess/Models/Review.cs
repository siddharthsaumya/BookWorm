﻿using System;
using System.Collections.Generic;

namespace BookwormBackend.DataAccess.Models
{
    public partial class Review
    {
        public int Id { get; set; }
        public int? BookId { get; set; }
        public int? UserId { get; set; }
        public string? ReviewContent { get; set; }
        public DateTime? ReviewDate { get; set; }
        public int? Rating { get; set; }

        public virtual Book? Book { get; set; }
        public virtual User? User { get; set; }
    }
}
