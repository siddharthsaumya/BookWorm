﻿using System;
using System.Collections.Generic;

namespace BookwormBackend.DataAccess.Models
{
    public partial class Book
    {
        public Book()
        {
            CartItems = new HashSet<CartItem>();
            OrderItems = new HashSet<OrderItem>();
            Reviews = new HashSet<Review>();
        }

        public int Id { get; set; }
        public string Title { get; set; } = null!;
        public string Author { get; set; } = null!;
        public string? Description { get; set; }
        public int Condition { get; set; }
        public int Price { get; set; }
        public int? TotalPages { get; set; }
        public string? Isbn { get; set; }
        public string? Publisher { get; set; }
        public DateTime? PublicationDate { get; set; }
        public string? Language { get; set; }
        public int? NumberOfCopies { get; set; }
        public string? CoverImage { get; set; }
        public int? TargetAge { get; set; }
        public int? GenreId { get; set; }
        public int? SellerId { get; set; }
        public int? Status { get; set; }

        public virtual Genre? Genre { get; set; }
        public virtual User? Seller { get; set; }
        public virtual ICollection<CartItem> CartItems { get; set; }
        public virtual ICollection<OrderItem> OrderItems { get; set; }
        public virtual ICollection<Review> Reviews { get; set; }
    }
}
