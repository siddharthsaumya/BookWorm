﻿using System;
using System.Collections.Generic;

namespace BookwormBackend.DataAccess.Models
{
    public partial class User
    {
        public User()
        {
            Addresses = new HashSet<Address>();
            Books = new HashSet<Book>();
            CartItems = new HashSet<CartItem>();
            Orders = new HashSet<Order>();
            Reviews = new HashSet<Review>();
        }

        public int Id { get; set; }
        public string Name { get; set; } = null!;
        public string Username { get; set; } = null!;
        public string Password { get; set; } = null!;
        public string Email { get; set; } = null!;
        public bool? IsActive { get; set; }
        public int? RoleId { get; set; }

        public virtual ICollection<Address>? Addresses { get; set; }
        public virtual ICollection<Book>? Books { get; set; }
        public virtual ICollection<CartItem>? CartItems { get; set; }
        public virtual ICollection<Order>? Orders { get; set; }
        public virtual ICollection<Review>? Reviews { get; set; }
    }
}
