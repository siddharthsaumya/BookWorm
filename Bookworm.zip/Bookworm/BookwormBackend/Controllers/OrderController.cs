﻿using BookwormBackend.Services.DTOs;
using BookwormBackend.Services.Services.IServices;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace MyWebApiProject.Controllers
{
    [ApiController]
    [Route("api/orders")]
    public class OrderController : ControllerBase
    {
        private readonly IOrderService _orderService;

        public OrderController(IOrderService orderService)
        {
            _orderService = orderService;
        }

        [HttpGet]
        public IActionResult GetAllOrders()
        {
            IEnumerable<OrderDTO> orders = _orderService.GetAllOrders();
            return Ok(orders);
        }

        [HttpGet("{buyerId}")]
        public async Task<IActionResult> GetOrdersByBuyerId(int buyerId)
        {
            try
            {
                IEnumerable<OrderDTO> orders = await _orderService.GetOrdersByBuyerIdAsync(buyerId);
                return Ok(orders);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred while retrieving orders: {ex.Message}");
            }
        }
    }
}