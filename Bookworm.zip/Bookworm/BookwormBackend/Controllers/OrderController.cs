﻿using BookwormBackend.Services.DTOs;
using BookwormBackend.Services.Services.IServices;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace MyWebApiProject.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class OrderController : ControllerBase
    {
        private readonly IOrderService _orderService;

        public OrderController(IOrderService orderService)
        {
            _orderService = orderService;
        }

        [HttpGet("Get/All")]
        public async Task<ActionResult<IEnumerable<OrderDTO>>> GetAllOrders()
        {
            var orders = await _orderService.GetAllOrders();
            if (orders == null)
            {
                return NotFound();
            }
            return Ok(orders);
        }

        [HttpGet("Get/{ID}")]
        public async Task<ActionResult<IEnumerable<OrderDTO>>> GetOrdersByBuyerId(int id)
        {
            var orders = await _orderService.GetOrdersByBuyerId(id);
            if (orders == null)
            {
                return NotFound();
            }
            return Ok(orders);
        }

        [HttpPost("Add")]
        public async Task<IActionResult> CreateOrder(OrderDTO orderDTO)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var orderId = await _orderService.CreateOrderAsync(orderDTO);
                return Ok(orderId);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPatch("Update-ByOrderID/Status/{ID}/{Status}")]
        public async Task<IActionResult> UpdateOrderStatus(int orderId, int status)
        {
            var result = await _orderService.UpdateOrderStatusAsync(orderId, status);
            if (result)
                return NoContent(); // Status updated successfully
            else
                return NotFound(); // Order not found
        }

    }
}