﻿using BookwormBackend.Services.DTOs;
using BookwormBackend.Services.Services.IServices;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BookwormBackend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AddressController : ControllerBase
    {
        private readonly IAddressService _addressService;

        public AddressController(IAddressService addressService)
        {
            _addressService = addressService;
        }

        [HttpPost]
        public IActionResult AddAddress([FromBody] AddressDTO addressDTO)
        {
            var addedAddress = _addressService.AddAddress(addressDTO);
            if (addedAddress == null)
            {
                return BadRequest("Failed to add address.");
            }
            return Ok("Address Saved");
        }
    }
}
