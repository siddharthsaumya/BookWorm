﻿using BookwormBackend.DataAccess.Models;
using BookwormBackend.DataAccess.Repositories.IRepositories;
using BookwormBackend.Services.DTOs;
using BookwormBackend.Services.Services.IServices;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BookwormBackend.Controllers
{
    [ApiController]
    [Route("api/Auth")]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService _authService;
        private readonly IUserService _userService; 

        public AuthController(IAuthService authService, IUserService userService)
        {
            _authService = authService;
            _userService = userService;
        }

        [HttpPost("Register")]
        public async Task<IActionResult> Register(RegisterDTO user)
        {
            var existingUsername = await _userService.GetUserByUsername(user.Username);
            var existingEmail = await _userService.GetUserByUsername(user.Username);
            if (existingUsername != null)
            {
                return Conflict("Username is already taken");
            }else if (existingEmail != null)
            {
                return Conflict("Email already exist");
            }

            var newUser = await _authService.Register(user);
            var Token = await _authService.Login(newUser.Username, newUser.Password);
            return Ok(Token);
        }

        [HttpPost("Login")]
        public async Task<IActionResult> Login(LoginDTO loginModel)
        {
            var Token = await _authService.Login(loginModel.Username, loginModel.Password);
            if (Token == null)
            {
                return Conflict("Invalid Credentials");
            }

            return Ok(Token);
        }
    }
}
