﻿using BookwormBackend.Services.DTOs;
using BookwormBackend.Services.Services.IServices;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BookwormBackend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly IUserService _userService;

        public UsersController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpGet("{userId}")]
        public IActionResult GetUserById(int userId)
        {
            var user = _userService.GetUserById(userId);
            if (user == null)
            {
                return NotFound($"User with ID {userId} not found.");
            }
            return Ok(user);
        }

        [HttpPost]
        public IActionResult CreateUser([FromBody] UserDTO userDTO)
        {
            var createdUser = _userService.CreateUser(userDTO);
            return CreatedAtAction(nameof(GetUserById), new { userId = createdUser.Id }, createdUser);
        }

        [HttpPatch("{userId}/isActive")]
        public IActionResult UpdateUserIsActive(int userId, [FromBody] UserIsActiveUpdateDTO isActiveUpdate)
        {
            var updatedUser = _userService.UpdateUserIsActive(userId, isActiveUpdate);
            if (updatedUser == null)
            {
                return NotFound($"User with ID {userId} not found.");
            }
            return Ok(updatedUser);
        }

        [HttpPatch("{userId}/isSeller")]
        public IActionResult UpdateUserIsSeller(int userId, [FromBody] UserIsSellerUpdateDTO isSellerUpdate)
        {
            var updatedUser = _userService.UpdateUserIsSeller(userId, isSellerUpdate);
            if (updatedUser == null)
            {
                return NotFound($"User with ID {userId} not found.");
            }
            return Ok(updatedUser);
        }

    }
}
