﻿using BookwormBackend.Services.DTOs;
using BookwormBackend.Services.Services.IServices;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BookwormBackend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly IUserService _userService;

        public UsersController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpGet("Get/{userId}")] // Change "ID" to "userId"
        public IActionResult GetUserById(int userId) // Keep the parameter name as "userId"
        {
            var user = _userService.GetUserById(userId);
            if (user == null)
            {
                return NotFound($"User with ID {userId} not found.");
            }
            return Ok(user);
        }

        [HttpPost("Add")]
        public IActionResult CreateUser([FromBody] UserDTO userDTO)
        {
            var createdUser = _userService.CreateUser(userDTO);
            return CreatedAtAction(nameof(GetUserById), new { userId = createdUser.Id }, createdUser);
        }

        [HttpPatch("Update-ByUserID/Active/{ID}")]
        public IActionResult UpdateUserIsActive(int userId, [FromBody] UserIsActiveUpdateDTO isActiveUpdate)
        {
            var updatedUser = _userService.UpdateUserIsActive(userId, isActiveUpdate);
            if (updatedUser == null)
            {
                return NotFound($"User with ID {userId} not found.");
            }
            return Ok(updatedUser);
        }

        [HttpPatch("Update-ByUserID/Role/{ID}")]
        public IActionResult UpdateUserIsSeller(int userId, [FromBody] UserIsSellerUpdateDTO isSellerUpdate)
        {
            var updatedUser = _userService.UpdateUserIsSeller(userId, isSellerUpdate);
            if (updatedUser == null)
            {
                return NotFound($"User with ID {userId} not found.");
            }
            return Ok(updatedUser);
        }

    }
}
