﻿using BookwormBackend.Services.DTOs;
using BookwormBackend.Services.Services.IServices;
using Microsoft.AspNetCore.Mvc;

namespace BookwormBackend.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BookController : ControllerBase
    {
        private readonly IBookService _bookService;

        public BookController(IBookService bookService)
        {
            _bookService = bookService;
        }

        [HttpGet]
        public IActionResult GetAllBooks()
        {
            var books = _bookService.GetAllBooks();
            return Ok(books);
        }

        [HttpGet("{id}")]
        public IActionResult GetBookById(int id)
        {
            var book = _bookService.GetBookById(id);
            if (book == null)
            {
                return NotFound();
            }
            return Ok(book);
        }

        [HttpGet("by-sellerId/{userID}")]
        public IActionResult GetBooksBySellerId(int userID)
        {
            var books = _bookService.GetBooksBySellerId(userID);
            if (books == null || !books.Any())
            {
                return NotFound("No books found for the specified seller ID.");
            }
            return Ok(books);
        }

        [HttpPost]
        public IActionResult AddBook(BookDTO book)
        {
            _bookService.AddBook(book);
            return CreatedAtAction(nameof(GetBookById), new { id = book.Id }, book);
        }

        [HttpPut("{id}")]
        public IActionResult UpdateBook(int id, BookDTO book)
        {
            try
            {
                _bookService.UpdateBook(id, book);
                return NoContent();
            }
            catch (ArgumentException ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpPatch("book-condition/{id}")]
        public IActionResult UpdateBookCondition(int id, [FromBody] BookConditionUpdateDTO conditionUpdate)
        {
            var updatedBook = _bookService.UpdateBookCondition(id, conditionUpdate);
            if (updatedBook == null)
            {
                return NotFound($"Book with ID {id} not found.");
            }
            return Ok(updatedBook);
        }

        [HttpPatch("approval-status/{id}")]
        public IActionResult UpdateBookStatus(int id, [FromBody] BookStatusUpdateDTO statusUpdate)
        {
            var updatedBook = _bookService.UpdateBookStatus(id, statusUpdate);
            if (updatedBook == null)
            {
                return NotFound($"Book with ID {id} not found.");
            }
            return Ok(updatedBook);
        }

        [HttpPatch("copies-minus-one/{id}")]
        public IActionResult UpdateBookNumberOfCopies(int id)
        {
            var updatedBook = _bookService.UpdateBookNumberOfCopies(id);
            if (updatedBook == null)
            {
                return NotFound($"Book with ID {id} not found.");
            }
            return Ok(updatedBook);
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteBook(int id)
        {
            try
            {
                _bookService.DeleteBook(id);
                return NoContent();
            }
            catch (ArgumentException ex)
            {
                return NotFound(ex.Message);
            }
        }
    }
}
