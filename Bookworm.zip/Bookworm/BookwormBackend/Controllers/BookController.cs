﻿using BookwormBackend.Services.DTOs;
using BookwormBackend.Services.Services.IServices;
using Microsoft.AspNetCore.Mvc;

namespace BookwormBackend.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BookController : ControllerBase
    {
        private readonly IBookService _bookService;

        public BookController(IBookService bookService)
        {
            _bookService = bookService;
        }

        [HttpGet("Get/All")]
        public IActionResult GetAllBooks()
        {
            var books = _bookService.GetAllBooks();
            return Ok(books);
        }

        [HttpGet("Get/{ID}")]
        public IActionResult GetBookById(int id)
        {
            var book = _bookService.GetBookById(id);
            if (book == null)
            {
                return NotFound();
            }
            return Ok(book);
        }

        [HttpGet("Get-BySellerId/{ID}")]
        public IActionResult GetBooksBySellerId(int userID)
        {
            var books = _bookService.GetBooksBySellerId(userID);
            if (books == null || !books.Any())
            {
                return NotFound("No books found for the specified seller ID.");
            }
            return Ok(books);
        }

        [HttpPost("Add")]
        public IActionResult AddBook(BookDTO book)
        {
            _bookService.AddBook(book);
            return CreatedAtAction(nameof(GetBookById), new { id = book.Id }, book);
        }

        [HttpPut("Update/{ID}")]
        public IActionResult UpdateBook(int id, BookDTO book)
        {
            try
            {
                _bookService.UpdateBook(id, book);
                return NoContent();
            }
            catch (ArgumentException ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpPatch("Update/Condition/{ID}")]
        public IActionResult UpdateBookCondition(int id, [FromBody] BookConditionUpdateDTO conditionUpdate)
        {
            var updatedBook = _bookService.UpdateBookCondition(id, conditionUpdate);
            if (updatedBook == null)
            {
                return NotFound($"Book with ID {id} not found.");
            }
            return Ok(updatedBook);
        }

        [HttpPatch("Update/Status/{ID}")]
        public IActionResult UpdateBookStatus(int id, [FromBody] BookStatusUpdateDTO statusUpdate)
        {
            var updatedBook = _bookService.UpdateBookStatus(id, statusUpdate);
            if (updatedBook == null)
            {
                return NotFound($"Book with ID {id} not found.");
            }
            return Ok(updatedBook);
        }

        [HttpPatch("Update/CopiesMinusOne/{ID}")]
        public IActionResult UpdateBookNumberOfCopies(int id)
        {
            var updatedBook = _bookService.UpdateBookNumberOfCopies(id);
            if (updatedBook == null)
            {
                return NotFound($"Book with ID {id} not found.");
            }
            return Ok(updatedBook);
        }

        [HttpDelete("Delete/{ID}")]
        public IActionResult DeleteBook(int id)
        {
            try
            {
                _bookService.DeleteBook(id);
                return NoContent();
            }
            catch (ArgumentException ex)
            {
                return NotFound(ex.Message);
            }
        }
    }
}
