﻿using BookwormBackend.Services.DTOs;
using BookwormBackend.Services.Services.IServices;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BookwormBackend.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CartController : ControllerBase
    {
        private readonly ICartService _cartService;

        public CartController(ICartService cartService)
        {
            _cartService = cartService;
        }

        [HttpGet("Get-ByUserID/{ID}")]
        public async Task<IActionResult> GetCartByUserId(int userId)
        {
            var cartItems = await _cartService.GetCartItemsByUserId(userId);
            if (cartItems == null)
            {
                return NotFound();
            }

            return Ok(cartItems);
        }

        [HttpPost("Add")]
        public async Task<IActionResult> AddToCart([FromBody] CartDTO cartItemDTO)
        {
            try
            {
                // Call the service method to add the item to the cart
                var addedItem = await _cartService.AddToCart(cartItemDTO);
                return Ok(addedItem);
            }
            catch (Exception ex)
            {
                // Handle any errors and return a suitable response
                return StatusCode(500, $"An error occurred: {ex.Message}");
            }
        }

        [HttpPatch("Update/Quantity/{ID}")]
        public async Task<IActionResult> UpdateCartItemQuantity(int id, [FromBody] CartQuantityDTO cartQuantityDTO)
        {
            try
            {
                await _cartService.UpdateCartItemQuantityAsync(id, cartQuantityDTO);
                return Ok("Cart item quantity updated successfully.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred while updating cart item quantity: {ex.Message}");
            }
        }

        [HttpDelete("Delete/{ID}")]
        public async Task<IActionResult> DeleteCartItem(int id)
        {
            try
            {
                await _cartService.DeleteCartItemAsync(id);
                return Ok($"Cart item with ID {id} deleted successfully.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred while deleting the cart item: {ex.Message}");
            }
        }

    }
}
