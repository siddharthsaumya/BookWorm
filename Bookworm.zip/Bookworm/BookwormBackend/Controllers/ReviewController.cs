﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using BookwormBackend.Services.DTOs;
using BookwormBackend.Services.Services.IServices;
using BookwormBackend.DataAccess.Models;
using BookwormBackend.Services.Services;

namespace BookwormBackend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReviewController : ControllerBase
    {
        private readonly IReviewService _reviewService;

        public ReviewController(IReviewService reviewService)
        {
            _reviewService = reviewService;
        }

        [HttpGet]
        public IActionResult GetAllReviews()
        {
            var reviews = _reviewService.GetAllReviews();
            return Ok(reviews);
        }

        [HttpPost]
        public IActionResult AddReview(ReviewDTO review)
        {
            _reviewService.AddReview(review);
            return Ok("Successfully Added");
        }

        [HttpGet("by-bookId/{bookID}")]
        public IActionResult GetReviewsByBookId(int bookID)
        {
            var reviews = _reviewService.GetReviewsByBookId(bookID);
            if (reviews == null || !reviews.Any())
            {
                return NotFound("No books found for the specified seller ID.");
            }
            return Ok(reviews);
        }

    }
}
