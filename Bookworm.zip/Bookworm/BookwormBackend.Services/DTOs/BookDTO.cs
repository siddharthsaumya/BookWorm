﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookwormBackend.Services.DTOs
{
    public class BookDTO
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public string? Description { get; set; }
        public int Condition { get; set; }
        public int Price { get; set; }
        public int? TotalPages { get; set; }
        public string? Isbn { get; set; }
        public string? Publisher { get; set; }
        public DateTime? PublicationDate { get; set; }
        public string? Language { get; set; }
        public int? NumberOfCopies { get; set; }
        public string? CoverImage { get; set; }
        public int? TargetAge { get; set; }
        public string? Genre { get; set; }
        public int? GenreID { get; set; }
        public int? SellerId { get; set; }
        public int? Status { get; set; }
    }
}
