﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookwormBackend.Services.DTOs
{
    public class OrderDTO
    {
        public int ID { get; set; }
        public int? BuyerID { get; set; }
        public DateTime? OrderDate { get; set; }
        public int? BookID { get; set; }
        public int? Quantity { get; set; }
        public int? Amount { get; set; }
        public int? Status { get; set; }
        public BookDTO? Book { get; set; }

    }

}
