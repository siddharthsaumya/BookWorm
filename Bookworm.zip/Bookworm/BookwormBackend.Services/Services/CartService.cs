﻿using BookwormBackend.DataAccess.Models;
using BookwormBackend.DataAccess.Repositories.IRepositories;
using BookwormBackend.Services.DTOs;
using BookwormBackend.Services.Services.IServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookwormBackend.Services.Services
{
    public class CartService : ICartService
    {
        private readonly ICartRepository _cartRepository;

        public CartService(ICartRepository cartRepository)
        {
            _cartRepository = cartRepository;
        }

        public async Task<IEnumerable<CartDTO>> GetCartItemsByUserId(int userId)
        {
            var cartItems = await _cartRepository.GetCartItemsByUserId(userId);
            return cartItems.Select(c => ConvertToCartItemDTO(c));
        }

        public async Task<CartDTO> AddToCart(CartDTO cartDTO)
        {
            var cartItem = ConvertToCartItem(cartDTO);
            var addedCartItem = await _cartRepository.AddToCart(cartItem);
            return ConvertToCartItemDTO(addedCartItem);
        }

        public async Task UpdateCartItemQuantityAsync(int id, CartQuantityDTO cartQuantityDTO)
        {
            var existingCartItem = await _cartRepository.GetCartItemByIdAsync(id);
            if (existingCartItem == null)
            {
                throw new Exception($"Cart item with ID {id} not found.");
            }

            existingCartItem.Quantity = cartQuantityDTO.Quantity;

            await _cartRepository.UpdateCartItemAsync(existingCartItem);
        }

        public async Task DeleteCartItemAsync(int id)
        {
            try
            {
                await _cartRepository.DeleteCartItemAsync(id);
            }
            catch (Exception ex)
            {
                // Handle exception (log, throw, etc.)
                throw new Exception($"Error deleting cart item with ID {id}.", ex);
            }
        }


        private CartItem ConvertToCartItem(CartDTO cartDTO)
        {
            return new CartItem
            {
                UserId = cartDTO.UserId,
                BookId = cartDTO.BookId,
                Quantity = cartDTO.Quantity
            };
        }
        private CartDTO ConvertToCartItemDTO(CartItem cartItem)
        {
            if (cartItem == null)
            {
                return null;
            }

            return new CartDTO
            {
                Id = cartItem.Id,
                UserId = cartItem.UserId,
                Quantity = cartItem.Quantity,
                Book = ConvertToBookDTO(cartItem.Book)
            };
        }

        private BookDTO ConvertToBookDTO(Book book)
        {
            if (book == null)
            {
                return null;
            }

            return new BookDTO
            {
                Id = book.Id,
                Title = book.Title,
                Author = book.Author,
                Condition = book.Condition,
                Price = book.Price,
                TotalPages = book.TotalPages,
                Publisher = book.Publisher,
                CoverImage = book.CoverImage,
                Genre = book.Genre.Name,
                SellerName = book.Seller.Name,
            };
        }
    }
}
