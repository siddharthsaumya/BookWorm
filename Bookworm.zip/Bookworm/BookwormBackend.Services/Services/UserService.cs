﻿using BookwormBackend.DataAccess.Models;
using BookwormBackend.DataAccess.Repositories;
using BookwormBackend.DataAccess.Repositories.IRepositories;
using BookwormBackend.Services.DTOs;
using BookwormBackend.Services.Services.IServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookwormBackend.Services.Services
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;

        public UserService(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        public UserDTO GetUserById(int userId)
        {
            var user = _userRepository.GetById(userId);
            var addressTemp = _userRepository.GetAddressByUserId(userId);
            if (user == null)
            {
                return null;
            }

            var userDTO = ConvertToUserDTO(user);

            if (addressTemp != null)
            {
                userDTO.Address1 = addressTemp.Address1;
                userDTO.City = addressTemp.City;
                userDTO.PostalCode = addressTemp.PostalCode;
                userDTO.Country = addressTemp.Country;
                userDTO.MobileNumber = addressTemp.MobileNumber;
            }

            return userDTO;
        }

        public UserDTO CreateUser(UserDTO userDTO)
        {
            var newUser = ConvertToUser(userDTO);
            _userRepository.Add(newUser);
            return userDTO;
        }

        public UserDTO UpdateUserIsActive(int userId, UserIsActiveUpdateDTO isActiveUpdate)
        {
            var user = _userRepository.GetById(userId);
            if (user == null)
            {
                return null;
            }

            user.IsActive = isActiveUpdate.IsActive;
            _userRepository.Update(user);

            return ConvertToUserDTO(user);
        }

        public UserDTO UpdateUserIsSeller(int userId, UserIsSellerUpdateDTO isSellerUpdate)
        {
            var user = _userRepository.GetById(userId);
            if (user == null)
            {
                return null;
            }

            user.RoleId = isSellerUpdate.RoleId;
            _userRepository.Update(user);

            return ConvertToUserDTO(user);
        }

        public async Task<User> GetUserByUsername(string username)
        {
            return await _userRepository.GetUserByUsername(username);
        }

        public async Task<User> GetUserByEmail(string email)
        {
            return await _userRepository.GetUserByEmail(email);
        }

        private UserDTO ConvertToUserDTO(User user)
        {
            if (user == null)
            {
                return null;
            }

            return new UserDTO
            {
                Id = user.Id,
                Name = user.Name,
                Username = user.Username,
                Password = user.Password,
                Email = user.Email,
                IsActive = user.IsActive,
                RoleId = user.RoleId
            };
        }

        private User ConvertToUser(UserDTO userDTO)
        {
            return new User
            {
                Id = userDTO.Id,
                Name = userDTO.Name,
                Username = userDTO.Username,
                Password = userDTO.Password,
                Email = userDTO.Email,
                IsActive = userDTO.IsActive,
                RoleId = userDTO.RoleId
            };
        }

    }
}
