﻿using BookwormBackend.DataAccess.Models;
using BookwormBackend.DataAccess.Repositories.IRepositories;
using BookwormBackend.Services.DTOs;
using BookwormBackend.Services.Services.IServices;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Authentication;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace BookwormBackend.Services.Services
{
    public class AuthService : Controller, IAuthService
    {
        private readonly IUserRepository _userRepository;
        private readonly IConfiguration _configuration;

        public AuthService(IUserRepository userRepository, IConfiguration configuration)
        {
            _userRepository = userRepository;
            _configuration = configuration;
        }

        public async Task<User> Register(RegisterDTO registerDTO)
        {
            var existingUser = await _userRepository.GetUserByUsername(registerDTO.Username);
            if (existingUser != null)
                throw new Exception("Username already exists");

            var newUser = new User
            {
                Name = registerDTO.Name,
                Username = registerDTO.Username,
                Password = registerDTO.Password,
                Email = registerDTO.Email,
                RoleId = 2
            };

            return await _userRepository.AddUser(newUser);
        }

        public async Task<string> Login(string username, string password)
        {
            var user = await _userRepository.GetUserByUsername(username);
            if (user == null)
                throw new AuthenticationException("User not found");

            if (user.Password != password)
                throw new AuthenticationException("Invalid Password");

            return GenerateJwtToken(user);
        }




        private string GenerateJwtToken(User user)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.UTF8.GetBytes(_configuration.GetValue<string>("JWTSecret"));

            var signingKey = new SymmetricSecurityKey(key);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Issuer = _configuration["JWTIssuer"],
                Audience = _configuration["JWTAudience"],
                Subject = new ClaimsIdentity(new[]
                {
                    new System.Security.Claims.Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                    new System.Security.Claims.Claim(ClaimTypes.Role, user.RoleId.ToString())

                 }),

                Expires = DateTime.UtcNow.AddHours(168),
                SigningCredentials = new SigningCredentials(signingKey, SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }
    }
}
