﻿using AutoMapper;
using BookwormBackend.DataAccess.Models;
using BookwormBackend.DataAccess.Repositories.IRepositories;
using BookwormBackend.Services.DTOs;
using BookwormBackend.Services.Services.IServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace BookwormBackend.Services.Services
{
    public class BookService : IBookService
    {
        private readonly IBookRepository _bookRepository;

        public BookService(IBookRepository bookRepository)
        {
            _bookRepository = bookRepository ?? throw new ArgumentNullException(nameof(bookRepository));
        }

        public IEnumerable<BookDTO> GetAllBooks()
        {
            var books = _bookRepository.GetAll();
            var bookDTOs = new List<BookDTO>();

            foreach (var book in books)
            {
                var bookDTO = ConvertToBookDTO(book);
                bookDTOs.Add(bookDTO);
            }

            return bookDTOs;
        }

        public BookDTO GetBookById(int id)
        {
            var book = _bookRepository.GetById(id);
            return ConvertToBookDTO(book);
        }

        public IEnumerable<BookDTO> GetBooksBySellerId(int sellerId)
        {
            var books = _bookRepository.GetBooksBySellerId(sellerId);
            return books.Select(book => ConvertToBookDTO(book));
        }

        public void AddBook(BookDTO book)
        {
            var newBook = ConvertToBook(book);
            _bookRepository.Add(newBook);
        }

        public void UpdateBook(int id, BookDTO book)
        {
            var existingBook = _bookRepository.GetById(id);
            if (existingBook == null)
            {
                throw new ArgumentException($"Book with ID {id} not found.");
            }

            UpdateBookFromDTO(existingBook, book);
            _bookRepository.Update(existingBook);
        }

        public BookDTO UpdateBookCondition(int bookId, BookConditionUpdateDTO conditionUpdate)
        {
            var book = _bookRepository.GetById(bookId);
            if (book == null)
            {
                return null;
            }

            // Update the condition
            book.Condition = conditionUpdate.Condition;

            // Save changes to the database
            _bookRepository.Update(book);

            // Return updated book DTO
            return ConvertToBookDTO(book);
        }

        public BookDTO UpdateBookStatus(int bookId, BookStatusUpdateDTO statusUpdate)
        {
            var book = _bookRepository.GetById(bookId);
            if (book == null)
            {
                return null;
            }

            // Update the status
            book.Status = statusUpdate.Status;

            // Save changes to the database
            _bookRepository.Update(book);

            // Return updated book DTO
            return ConvertToBookDTO(book);
        }

        public BookDTO UpdateBookNumberOfCopies(int bookId)
        {
            var book = _bookRepository.GetById(bookId);
            if (book == null)
            {
                return null;
            }

            // Deduct one copy
            if (book.NumberOfCopies > 0)
            {
                book.NumberOfCopies--;
            }

            // Save changes to the database
            _bookRepository.Update(book);

            // Return updated book DTO
            return ConvertToBookDTO(book);
        }

        public void DeleteBook(int id)
        {
            var existingBook = _bookRepository.GetById(id);
            if (existingBook == null)
            {
                throw new ArgumentException($"Book with ID {id} not found.");
            }

            _bookRepository.Delete(existingBook);
        }

        // Convert Book entity to BookDTO
        private BookDTO ConvertToBookDTO(Book book)
        {
            if (book == null)
            {
                return null;
            }

            return new BookDTO
            {
                // Map properties here
                // Example: Id = book.Id, Title = book.Title, ...
                Id = book.Id,
                Title = book.Title,
                Author = book.Author,
                Description = book.Description,
                Condition = book.Condition,
                Price = book.Price,
                TotalPages = book.TotalPages,
                Isbn = book.Isbn,
                Publisher = book.Publisher,
                PublicationDate = book.PublicationDate,
                Language = book.Language,
                NumberOfCopies = book.NumberOfCopies,
                CoverImage = book.CoverImage,
                TargetAge = book.TargetAge,
                Genre = book.Genre.Name,
                GenreID = book.GenreId,
                SellerName = book.Seller.Name,
                SellerId = book.SellerId,
                Status = book.Status
            };
        }

        // Convert list of Book entities to list of BookDTOs
        private IEnumerable<BookDTO> ConvertToBookDTOs(IEnumerable<Book> books)
        {
            var bookDTOs = new List<BookDTO>();
            foreach (var book in books)
            {
                bookDTOs.Add(ConvertToBookDTO(book));
            }
            return bookDTOs;
        }

        // Convert BookDTO to Book entity
        private Book ConvertToBook(BookDTO bookDTO)
        {
            if (bookDTO == null)
            {
                return null;
            }

            return new Book
            {
                // Map properties here
                // Example: Id = bookDTO.Id, Title = bookDTO.Title, ...
                Id = bookDTO.Id,
                Title = bookDTO.Title,
                Author = bookDTO.Author,
                Description = bookDTO.Description,
                Condition = bookDTO.Condition,
                Price = bookDTO.Price,
                TotalPages = bookDTO.TotalPages,
                Isbn = bookDTO.Isbn,
                Publisher = bookDTO.Publisher,
                PublicationDate = bookDTO.PublicationDate,
                Language = bookDTO.Language,
                NumberOfCopies = bookDTO.NumberOfCopies,
                CoverImage = bookDTO.CoverImage,
                TargetAge = bookDTO.TargetAge,
                GenreId = bookDTO.GenreID,
                SellerId = bookDTO.SellerId,
                Status = bookDTO.Status
            };
        }


        // Update existing Book entity from BookDTO
        private void UpdateBookFromDTO(Book existingBook, BookDTO bookDTO)
        {
            // Update properties here
            // Example: existingBook.Title = bookDTO.Title, ...

                if (bookDTO == null)
                {
                    return;
                }

                // Update properties here
                existingBook.Title = bookDTO.Title;
                existingBook.Author = bookDTO.Author;
                existingBook.Description = bookDTO.Description;
                existingBook.Price = bookDTO.Price;
                existingBook.TotalPages = bookDTO.TotalPages;
                existingBook.Isbn = bookDTO.Isbn;
                existingBook.Publisher = bookDTO.Publisher;
                existingBook.Language = bookDTO.Language;
                existingBook.CoverImage = bookDTO.CoverImage;
                existingBook.TargetAge = bookDTO.TargetAge;
                existingBook.GenreId = bookDTO.GenreID;
            }


    }
}
