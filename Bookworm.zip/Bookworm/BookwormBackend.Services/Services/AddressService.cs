﻿using BookwormBackend.DataAccess.Models;
using BookwormBackend.DataAccess.Repositories.IRepositories;
using BookwormBackend.Services.DTOs;
using BookwormBackend.Services.Services.IServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookwormBackend.Services.Services
{
    public class AddressService : IAddressService
    {
        private readonly IAddressRepository _addressRepository;

        public AddressService(IAddressRepository addressRepository)
        {
            _addressRepository = addressRepository;
        }

        public AddressDTO AddAddress(AddressDTO addressDTO)
        {
            var address = ConvertToAddress(addressDTO);
            _addressRepository.AddAddress(address);
            return ConvertToAddressDTO(address);
        }

        public AddressDTO UpdateAddress(int userId, AddressDTO addressDTO)
        {
            var existingAddress = _addressRepository.GetAddressByUserId(userId);
            if (existingAddress == null)
            {
                return null;
            }

            // Update existing address properties
            existingAddress.Address1 = addressDTO.Address1;
            existingAddress.City = addressDTO.City;
            existingAddress.PostalCode = addressDTO.PostalCode;
            existingAddress.Country = addressDTO.Country;
            existingAddress.MobileNumber = addressDTO.MobileNumber;

            _addressRepository.UpdateAddress(existingAddress);

            return ConvertToAddressDTO(existingAddress);
        }

        private Address ConvertToAddress(AddressDTO addressDTO)
        {
            return new Address
            {
                Id = addressDTO.Id,
                UserId = addressDTO.UserId,
                Address1 = addressDTO.Address1,
                City = addressDTO.City,
                Country = addressDTO.Country,
                MobileNumber = addressDTO.MobileNumber,
                PostalCode = addressDTO.PostalCode
            };
        }

        private AddressDTO ConvertToAddressDTO(Address address)
        {
            if (address == null)
            {
                return null;
            }

            return new AddressDTO
            {
                Id = address.Id,
                UserId = address.UserId,
                Address1 = address.Address1,
                City = address.City,
                Country = address.Country,
                MobileNumber = address.MobileNumber,
                PostalCode = address.PostalCode
            };
        }
    }
}
