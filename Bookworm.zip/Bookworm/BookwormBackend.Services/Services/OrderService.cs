﻿using BookwormBackend.DataAccess.Models;
using BookwormBackend.DataAccess.Repositories;
using BookwormBackend.DataAccess.Repositories.IRepositories;
using BookwormBackend.Services.DTOs;
using BookwormBackend.Services.Services.IServices;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookwormBackend.Services.Services
{
    public class OrderService : IOrderService
    {
        private readonly IOrderRepository _orderRepository;
        private readonly IBookRepository _bookRepository;

        public OrderService(IOrderRepository orderRepository, IBookRepository bookRepository) // Add IOrderItemRepository to constructor
        {
            _orderRepository = orderRepository;
            _bookRepository = bookRepository;
        }

        public IEnumerable<OrderDTO> GetAllOrders()
        {
            var orders = _orderRepository.GetAllOrders();
            return orders.Select(order => ConvertToOrderDTO(order));
        }

        public async Task<IEnumerable<OrderDTO>> GetOrdersByBuyerIdAsync(int buyerId)
        {
            var orders = await _orderRepository.GetOrdersByBuyerIdAsync(buyerId);
            return orders.Select(order => ConvertToOrderDTO(order));
        }




        private OrderDTO ConvertToOrderDTO(Order order)
        {
            return new OrderDTO
            {
                Id = order.Id,
                BuyerId = order.BuyerId,
                OrderDate = order.OrderDate,
                Status = order.Status,
                Items = order.OrderItems.Select(item => new OrderItemDTO
                {
                    Quantity = item.Quantity,
                    Amount = item.Amount,
                    Book = ConvertToBookDTO(_bookRepository.GetById((int)item.BookId))
                }).ToList()
            };
        }

        private BookOrderDTO ConvertToBookDTO(Book book)
        {

            return new BookOrderDTO
            {
                Title = book.Title,
                Author = book.Author,
                Description = book.Description,
                Price = book.Price,
                Publisher = book.Publisher,
                CoverImage = book.CoverImage,
                SellerName = book.Seller.Name
            };
        }
    }
}
