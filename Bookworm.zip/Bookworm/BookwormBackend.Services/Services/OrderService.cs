﻿using BookwormBackend.DataAccess.Models;
using BookwormBackend.DataAccess.Repositories;
using BookwormBackend.DataAccess.Repositories.IRepositories;
using BookwormBackend.Services.DTOs;
using BookwormBackend.Services.Services.IServices;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookwormBackend.Services.Services
{
    public class OrderService : IOrderService
    {
        private readonly IOrderRepository _orderRepository;

        public OrderService(IOrderRepository orderRepository)
        {
            _orderRepository = orderRepository;
        }

        public async Task<IEnumerable<OrderDTO>> GetAllOrders()
        {
            var orders = await _orderRepository.GetAllOrders();
            return orders.Select(order => ConvertToOrderDTO(order));
        }

        public async Task<IEnumerable<OrderDTO>> GetOrdersByBuyerId(int buyerId)
        {
            var orders = await _orderRepository.GetOrdersByBuyerId(buyerId);
            return orders.Select(order => ConvertToOrderDTO(order));
        }

        public async Task<int> CreateOrderAsync(OrderDTO orderDTO)
        {
            var order = new Order
            {
                BuyerId = orderDTO.BuyerID,
                OrderDate = orderDTO.OrderDate,
                BookId = orderDTO.BookID,
                Quantity = orderDTO.Quantity,
                Amount = orderDTO.Amount,
                Status = orderDTO.Status
            };

            await _orderRepository.AddOrderAsync(order);

            return order.Id;
        }

        public async Task<bool> UpdateOrderStatusAsync(int orderId, int status)
        {
            return await _orderRepository.UpdateOrderStatusAsync(orderId, status);
        }



        private OrderDTO ConvertToOrderDTO(Order order)
        {
            return new OrderDTO
            {
                ID = order.Id,
                BuyerID = order.BuyerId,
                OrderDate = order.OrderDate,
                Status = order.Status,
                Book = ConvertToBookDTO(order.Book),
                Quantity = order.Quantity,
                Amount = order.Amount
            };
        }

        private BookDTO ConvertToBookDTO(Book book)
        {
            if (book == null)
            {
                return null;
            }

            return new BookDTO
            {

                Id = book.Id,
                Title = book.Title,
                Author = book.Author,
                Condition = book.Condition,
                Price = book.Price,
                TotalPages = book.TotalPages,
                Publisher = book.Publisher,
                CoverImage = book.CoverImage,
                Genre = book.Genre.Name,
                SellerName = book.Seller.Name,
            };
        }



    }
}
