﻿using BookwormBackend.DataAccess.Models;
using BookwormBackend.DataAccess.Repositories;
using BookwormBackend.DataAccess.Repositories.IRepositories;
using BookwormBackend.Services.DTOs;
using BookwormBackend.Services.Services.IServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookwormBackend.Services.Services
{
    public class ReviewService : IReviewService
    {
        private readonly IReviewRepository _reviewRepository;

        public ReviewService(IReviewRepository reviewRepository)
        {
            _reviewRepository = reviewRepository ?? throw new ArgumentNullException(nameof(reviewRepository));
        }

        public IEnumerable<ReviewDTO> GetAllReviews()
        {
            var reviews = _reviewRepository.GetAll();
            var reviewDTOs = new List<ReviewDTO>();

            foreach (var review in reviews)
            {
                var reviewDTO = ConvertToReviewDTO(review);
                reviewDTOs.Add(reviewDTO);
            }

            return reviewDTOs;
        }

        public void AddReview(ReviewDTO review)
        {
            var newReview = ConvertToReview(review);
            _reviewRepository.Add(newReview);
        }

        public IEnumerable<ReviewDTO> GetReviewsByBookId(int bookId)
        {
            var reviews = _reviewRepository.GetReviewsByBookId(bookId);
            return reviews.Select(review => ConvertToReviewDTO(review));
        }

        private ReviewDTO ConvertToReviewDTO(Review review)
        {
            if (review == null)
            {
                return null;
            }

            return new ReviewDTO
            {
                Id = review.Id,
                BookId = review.BookId,
                UserId = review.UserId,
                ReviewContent  = review.ReviewContent,
                ReviewDate = review.ReviewDate,
                Rating  = review.Rating
            };
        }

        private Review ConvertToReview(ReviewDTO reviewDTO)
        {
            if (reviewDTO == null)
            {
                return null;
            }

            return new Review
            {
                BookId = reviewDTO.BookId,
                UserId = reviewDTO.UserId,
                ReviewContent = reviewDTO.ReviewContent,
                ReviewDate = reviewDTO.ReviewDate,
                Rating = reviewDTO.Rating

            };
        }

    }
}
