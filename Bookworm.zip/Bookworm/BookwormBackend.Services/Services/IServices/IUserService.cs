﻿using BookwormBackend.DataAccess.Models;
using BookwormBackend.Services.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace BookwormBackend.Services.Services.IServices
{
    public interface IUserService
    {
        UserDTO GetUserById(int userId);
        UserDTO CreateUser(UserDTO userDTO);
        UserDTO UpdateUserIsActive(int userId, UserIsActiveUpdateDTO isActiveUpdate);
        UserDTO UpdateUserIsSeller(int userId, UserIsSellerUpdateDTO isSellerUpdate);
        Task<User> GetUserByUsername(string username);

        Task<User> GetUserByEmail(string email);
    }
}
