﻿using BookwormBackend.Services.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookwormBackend.Services.Services.IServices
{
    public interface IBookService
    {
        IEnumerable<BookDTO> GetAllBooks();
        BookDTO GetBookById(int id);
        void AddBook(BookDTO book);
        void UpdateBook(int id, BookDTO book);
        void DeleteBook(int id);
    }
}
