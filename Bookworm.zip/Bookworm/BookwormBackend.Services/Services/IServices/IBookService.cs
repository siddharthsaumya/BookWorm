﻿using BookwormBackend.DataAccess.Models;
using BookwormBackend.Services.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookwormBackend.Services.Services.IServices
{
    public interface IBookService
    {
        IEnumerable<BookDTO> GetAllBooks();
        BookDTO GetBookById(int id);
        IEnumerable<BookDTO> GetBooksBySellerId(int sellerId);
        BookDTO UpdateBookCondition(int bookId, BookConditionUpdateDTO conditionUpdate);
        BookDTO UpdateBookStatus(int bookId, BookStatusUpdateDTO statusUpdate);
        BookDTO UpdateBookNumberOfCopies(int bookId);
        void AddBook(BookDTO book);
        void UpdateBook(int id, BookDTO book);
        void DeleteBook(int id);
    }
}
