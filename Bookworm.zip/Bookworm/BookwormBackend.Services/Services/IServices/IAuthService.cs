﻿using BookwormBackend.DataAccess.Models;
using BookwormBackend.Services.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookwormBackend.Services.Services.IServices
{
    public interface IAuthService
    {
        Task<string> Login(string username, string password);
        Task<User> Register(RegisterDTO registerDTO);
    }
}
