﻿using BookwormBackend.Services.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookwormBackend.Services.Services.IServices
{
    public interface IOrderService
    {
        IEnumerable<OrderDTO> GetAllOrders();
        Task<IEnumerable<OrderDTO>> GetOrdersByBuyerIdAsync(int buyerId);
    }
}
