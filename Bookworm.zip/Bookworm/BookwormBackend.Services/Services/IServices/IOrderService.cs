﻿using BookwormBackend.DataAccess.Models;
using BookwormBackend.Services.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookwormBackend.Services.Services.IServices
{
    public interface IOrderService
    {
        Task<IEnumerable<OrderDTO>> GetAllOrders();
        Task<IEnumerable<OrderDTO>> GetOrdersByBuyerId(int buyerId);

        Task<int> CreateOrderAsync(OrderDTO orderDTO);

        Task<bool> UpdateOrderStatusAsync(int orderId, int status);

    }
}
