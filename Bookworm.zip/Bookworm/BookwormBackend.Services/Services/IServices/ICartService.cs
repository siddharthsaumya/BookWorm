﻿using BookwormBackend.Services.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookwormBackend.Services.Services.IServices
{
    public interface ICartService
    {
        Task<IEnumerable<CartDTO>> GetCartItemsByUserId(int userId);
        Task<CartDTO> AddToCart(CartDTO cartDTO);
        Task UpdateCartItemQuantityAsync(int id, CartQuantityDTO cartQuantityDTO);
        Task DeleteCartItemAsync(int id);
    }
}
